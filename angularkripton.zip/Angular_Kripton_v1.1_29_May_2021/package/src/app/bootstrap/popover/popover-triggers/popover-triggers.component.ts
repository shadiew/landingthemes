import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-popover-triggers',
  templateUrl: './popover-triggers.component.html',
  styleUrls: ['./popover-triggers.component.css']
})
export class PopoverTriggersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
