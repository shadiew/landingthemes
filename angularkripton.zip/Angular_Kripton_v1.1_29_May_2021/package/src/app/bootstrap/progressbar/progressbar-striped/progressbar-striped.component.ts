import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-progressbar-striped',
  templateUrl: './progressbar-striped.component.html',
  styleUrls: ['./progressbar-striped.component.css']
})
export class ProgressbarStripedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
