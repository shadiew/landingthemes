import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-progressbar-showvalue',
  templateUrl: './progressbar-showvalue.component.html',
  styleUrls: ['./progressbar-showvalue.component.css']
})
export class ProgressbarShowvalueComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
